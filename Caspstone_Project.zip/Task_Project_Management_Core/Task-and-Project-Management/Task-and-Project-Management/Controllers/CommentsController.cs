using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TaskProjectManagement.Api.DTOs.Comment;
using TaskProjectManagement.Api.Services.Interfaces;

namespace TaskProjectManagement.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = "ViewerOrHigher")]
public class CommentsController(ICommentService svc) : ControllerBase
{
    private readonly ICommentService _svc = svc;

    [HttpPost]
    [Authorize(Policy = "TeamMemberOrHigher")]
    public async Task<IActionResult> Create(CommentCreateDto dto)
    {
        int authorId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        return Ok(await _svc.AddAsync(authorId, dto));
    }

    [HttpGet("{taskId:int}")]
    public async Task<IActionResult> GetByTask(int taskId)
        => Ok(await _svc.GetByTaskAsync(taskId));
}
