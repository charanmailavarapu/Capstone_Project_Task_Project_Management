using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TaskProjectManagement.Api.DTOs.Task;
using TaskProjectManagement.Api.Services.Interfaces;

namespace TaskProjectManagement.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = "ViewerOrHigher")]
public class TasksController(ITaskService svc) : ControllerBase
{
    private readonly ITaskService _svc = svc;

    [HttpPost]
    [Authorize(Policy = "ProjectManagerOrHigher")]
    public async Task<IActionResult> Create(TaskCreateDto dto)
        => Ok(await _svc.CreateAsync(dto));

    [HttpGet("{projectId:int}")]
    public async Task<IActionResult> GetByProject(int projectId)
        => Ok(await _svc.GetByProjectAsync(projectId));

    [HttpPut("{id:int}")]
    [Authorize(Policy = "TeamMemberOrHigher")]
    public async Task<IActionResult> Update(int id, TaskUpdateDto dto)
    {
        var t = await _svc.UpdateAsync(id, dto);
        return t is null ? NotFound() : Ok(t);
    }

    [HttpDelete("{id:int}")]
    [Authorize(Policy = "ProjectManagerOrHigher")]
    public async Task<IActionResult> Delete(int id)
        => await _svc.DeleteAsync(id) ? NoContent() : NotFound();

    [HttpPost("{id:int}/attachments")]
    [Authorize(Policy = "TeamMemberOrHigher")]
    [RequestSizeLimit(50_000_000)] // 50MB
    public async Task<IActionResult> Upload(int id, IFormFile? document, IFormFile? image)
        => await _svc.UploadAttachmentsAsync(id, document, image) ? NoContent() : NotFound();
}
