using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TaskProjectManagement.Api.DTOs.Notification;
using TaskProjectManagement.Api.Services.Interfaces;

namespace TaskProjectManagement.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = "TeamMemberOrHigher")]
public class NotificationsController(INotificationService svc) : ControllerBase
{
    private readonly INotificationService _svc = svc;

    [HttpPost]
    public async Task<IActionResult> Trigger(NotificationTriggerDto dto)
    {
        await _svc.TriggerAsync(dto);
        return Accepted();
    }
}
