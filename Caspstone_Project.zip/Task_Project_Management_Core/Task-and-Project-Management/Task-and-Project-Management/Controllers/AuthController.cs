using Microsoft.AspNetCore.Mvc;
using TaskProjectManagement.Api.DTOs.Auth;
using TaskProjectManagement.Api.Services.Interfaces;

namespace TaskProjectManagement.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController(IAuthService auth) : ControllerBase
{
    private readonly IAuthService _auth = auth;

    [HttpPost("register")]
    public async Task<IActionResult> Register(RegisterDto dto)
        => Ok(await _auth.RegisterAsync(dto));

    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginDto dto)
        => Ok(await _auth.LoginAsync(dto));
}
