using System.Text;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Task_Product_Management.Api.Data;
using Task_Product_Management.Api.Hubs;
using Task_Product_Management.Api.Models;
using Task_Product_Management.Api.Services;
using Task_Product_Management.Api.Services.Interfaces;

var builder = WebApplication.CreateBuilder(args);

// --------------------------------------
// Configuration
// --------------------------------------
var cfg = builder.Configuration;

// --------------------------------------
// Controllers + JSON
//  - Keep PascalCase (no naming policy)
//  - Serialize enums as strings ("Admin", "InProgress")
// --------------------------------------
builder.Services.AddControllers()
    .AddJsonOptions(o =>
    {
        o.JsonSerializerOptions.PropertyNamingPolicy = null;
        o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
    });

// --------------------------------------
// SignalR
// --------------------------------------
builder.Services.AddSignalR();

// --------------------------------------
// Swagger with Bearer
// --------------------------------------
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "TPM API", Version = "v1" });

    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Description = "Enter: Bearer {your token}",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT"
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });
});

// --------------------------------------
// CORS (Multiple dev origins)
// --------------------------------------
// Read array Cors:AllowedOrigins from appsettings (preferred).
// If missing, fallback to common React dev hosts.
var allowedOrigins =
    cfg.GetSection("Cors:AllowedOrigins").Get<string[]>() ??
    new[]
    {
        // CRA / Vite defaults (http + https)
        "http://localhost:3000",
        "https://localhost:3000",
        "http://127.0.0.1:3000",
        "https://127.0.0.1:3000",
        "http://localhost:5173",
        "https://localhost:5173",
        "http://127.0.0.1:5173",
        "https://127.0.0.1:5173"
    };

const string DevCorsPolicy = "DevCors";
builder.Services.AddCors(opt =>
{
    opt.AddPolicy(DevCorsPolicy, policy =>
        policy
            .WithOrigins(allowedOrigins)
            .AllowAnyHeader()
            .AllowAnyMethod()
            .AllowCredentials() // keep if you use cookies / SignalR auth
    );
});

// --------------------------------------
// EF Core
// --------------------------------------
builder.Services.AddDbContext<AppDbContext>(opt =>
    opt.UseSqlServer(cfg.GetConnectionString("DefaultConnection")));

// --------------------------------------
// DI Services
// --------------------------------------
builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<IProjectService, ProjectService>();
builder.Services.AddScoped<ITaskService, TaskService>();
builder.Services.AddScoped<ICommentService, CommentService>();
builder.Services.AddScoped<INotificationService, NotificationService>();

// Optional integrations (stubs)
builder.Services.Configure<SlackOptions>(cfg.GetSection("Slack"));
builder.Services.Configure<GoogleCalendarOptions>(cfg.GetSection("GoogleCalendar"));
builder.Services.Configure<JiraOptions>(cfg.GetSection("Jira"));
builder.Services.AddScoped<ISlackService, SlackService>();
builder.Services.AddScoped<IGoogleCalendarService, GoogleCalendarService>();
builder.Services.AddScoped<IJiraService, JiraService>();

// --------------------------------------
// Auth / JWT
// --------------------------------------
var key = cfg["Jwt:Key"] ?? "CHANGE_THIS_IN_PROD_32+CHARS";
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = cfg["Jwt:Issuer"] ?? "tpm.local",
            ValidAudience = cfg["Jwt:Audience"] ?? "tpm.local",
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key))
        };

        // Helpful logging while debugging JWT / SignalR locally
        options.Events = new JwtBearerEvents
        {
            OnAuthenticationFailed = ctx =>
            {
                Console.WriteLine($"[JWT] Auth failed: {ctx.Exception.Message}");
                return Task.CompletedTask;
            },
            OnChallenge = ctx =>
            {
                Console.WriteLine($"[JWT] Challenge: {ctx.Error} - {ctx.ErrorDescription}");
                return Task.CompletedTask;
            },
            OnMessageReceived = context =>
            {
                // Allow SignalR auth token via query string
                var accessToken = context.Request.Query["access_token"];
                var path = context.HttpContext.Request.Path;
                if (!string.IsNullOrEmpty(accessToken) && path.StartsWithSegments("/hubs/notifications"))
                {
                    context.Token = accessToken;
                }
                return Task.CompletedTask;
            }
        };
    });

// --------------------------------------
// Authorization policies
// --------------------------------------
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("ViewerOrHigher", p => p.RequireRole("Viewer", "TeamMember", "ProjectManager", "Admin"));
    options.AddPolicy("TeamMemberOrHigher", p => p.RequireRole("TeamMember", "ProjectManager", "Admin"));
    options.AddPolicy("ProjectManagerOrHigher", p => p.RequireRole("ProjectManager", "Admin"));
    options.AddPolicy("AdminOnly", p => p.RequireRole("Admin"));
});

var app = builder.Build();

// --------------------------------------
// Pipeline
// --------------------------------------
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// IMPORTANT: CORS BEFORE auth/authorization and before endpoints
app.UseCors(DevCorsPolicy);

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();
app.MapHub<NotificationHub>("/hubs/notifications");

app.Run();
