using TaskProjectManagement.Api.Models;
namespace TaskProjectManagement.Api.DTOs.Auth;
public record RegisterDto(string Email, string FullName, string Password, UserRole Role);
