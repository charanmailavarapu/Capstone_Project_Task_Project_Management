using TaskProjectManagement.Api.Models;
namespace TaskProjectManagement.Api.DTOs.Auth;
public record AuthResponseDto(string Token, int Id, string Email, string FullName, UserRole Role);
