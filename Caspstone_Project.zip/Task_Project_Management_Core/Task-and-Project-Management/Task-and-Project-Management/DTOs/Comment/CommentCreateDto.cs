namespace TaskProjectManagement.Api.DTOs.Comment;
public record CommentCreateDto(int TaskId, string Content);
