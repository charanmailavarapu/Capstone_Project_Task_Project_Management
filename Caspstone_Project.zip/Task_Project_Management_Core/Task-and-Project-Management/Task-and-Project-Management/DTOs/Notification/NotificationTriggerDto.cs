namespace TaskProjectManagement.Api.DTOs.Notification;
public record NotificationTriggerDto(int UserId, string Message);
