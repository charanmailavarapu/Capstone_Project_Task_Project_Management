using TaskProjectManagement.Api.Models;
using TaskStatus = TaskProjectManagement.Api.Models.TaskStatus;
namespace TaskProjectManagement.Api.DTOs.Task;
public record TaskUpdateDto(string Title, string? Description, TaskStatus Status, int? AssigneeId);
