namespace TaskProjectManagement.Api.DTOs.Project;
public record ProjectCreateDto(string Name, string? Description);
