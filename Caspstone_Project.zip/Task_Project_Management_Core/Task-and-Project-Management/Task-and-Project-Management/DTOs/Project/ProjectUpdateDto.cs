namespace TaskProjectManagement.Api.DTOs.Project;
public record ProjectUpdateDto(string Name, string? Description);
