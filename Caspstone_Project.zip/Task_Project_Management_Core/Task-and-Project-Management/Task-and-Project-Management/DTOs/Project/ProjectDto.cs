using TaskProjectManagement.Api.Models;
namespace TaskProjectManagement.Api.DTOs.Project;
public record ProjectDto(int Id, string Name, string? Description, int CreatedById, DateTime CreatedAt);
