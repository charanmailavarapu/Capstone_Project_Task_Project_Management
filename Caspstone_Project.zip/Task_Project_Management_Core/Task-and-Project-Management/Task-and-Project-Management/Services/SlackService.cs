using Microsoft.Extensions.Options;
using TaskProjectManagement.Api.Models;
using TaskProjectManagement.Api.Services.Interfaces;

namespace TaskProjectManagement.Api.Services;

public class SlackService(IOptions<SlackOptions> opts) : ISlackService
{
    public Task SendAsync(string message)
    {
        // TODO: post to Slack webhook if configured.
        // For capstone, keep as a stub.
        return Task.CompletedTask;
    }
}
