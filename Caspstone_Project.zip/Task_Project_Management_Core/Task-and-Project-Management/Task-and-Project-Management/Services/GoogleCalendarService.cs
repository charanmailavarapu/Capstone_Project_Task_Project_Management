using Microsoft.Extensions.Options;
using TaskProjectManagement.Api.Models;
using TaskProjectManagement.Api.Services.Interfaces;

namespace TaskProjectManagement.Api.Services;

public class GoogleCalendarService(IOptions<GoogleCalendarOptions> opts) : IGoogleCalendarService
{
    public Task<bool> AddEventAsync(string title, DateTime start, DateTime end)
    {
        // TODO: call Google Calendar API if configured
        return Task.FromResult(true);
    }
}
