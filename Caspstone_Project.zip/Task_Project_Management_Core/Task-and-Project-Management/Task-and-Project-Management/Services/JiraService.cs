using Microsoft.Extensions.Options;
using TaskProjectManagement.Api.Models;
using TaskProjectManagement.Api.Services.Interfaces;

namespace TaskProjectManagement.Api.Services;

public class JiraService(IOptions<JiraOptions> opts) : IJiraService
{
    public Task<bool> CreateIssueAsync(string summary, string description)
    {
        // TODO: call JIRA API if configured
        return Task.FromResult(true);
    }
}
