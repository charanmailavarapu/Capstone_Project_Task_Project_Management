using Microsoft.AspNetCore.SignalR;
using TaskProjectManagement.Api.DTOs.Notification;
using TaskProjectManagement.Api.Hubs;
using TaskProjectManagement.Api.Services.Interfaces;

namespace TaskProjectManagement.Api.Services;

public class NotificationService(IHubContext<NotificationHub> hub) : INotificationService
{
    private readonly IHubContext<NotificationHub> _hub = hub;

    public async Task TriggerAsync(NotificationTriggerDto dto)
    {
        // Broadcast to a specific user group or all
        await _hub.Clients.All.SendAsync("receiveNotification", new { dto.UserId, dto.Message, At = DateTime.UtcNow });
    }
}
