namespace TaskProjectManagement.Api.Services.Interfaces;
public interface IJiraService { Task<bool> CreateIssueAsync(string summary, string description); }
