using TaskProjectManagement.Api.DTOs.Auth;

namespace TaskProjectManagement.Api.Services.Interfaces;
public interface IAuthService
{
    Task<AuthResponseDto> RegisterAsync(RegisterDto dto);
    Task<AuthResponseDto> LoginAsync(LoginDto dto);
}
