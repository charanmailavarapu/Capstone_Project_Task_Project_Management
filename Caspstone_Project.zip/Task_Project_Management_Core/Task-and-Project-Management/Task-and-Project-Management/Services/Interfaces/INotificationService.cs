using TaskProjectManagement.Api.DTOs.Notification;
namespace TaskProjectManagement.Api.Services.Interfaces;
public interface INotificationService
{
    Task TriggerAsync(NotificationTriggerDto dto);
}
