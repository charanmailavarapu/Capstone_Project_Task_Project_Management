namespace TaskProjectManagement.Api.Services.Interfaces;
public interface IGoogleCalendarService { Task<bool> AddEventAsync(string title, DateTime start, DateTime end); }
