namespace TaskProjectManagement.Api.Services.Interfaces;
public interface ISlackService { Task SendAsync(string message); }
