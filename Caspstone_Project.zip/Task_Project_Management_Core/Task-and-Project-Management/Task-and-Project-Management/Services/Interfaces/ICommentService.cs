using TaskProjectManagement.Api.DTOs.Comment;
namespace TaskProjectManagement.Api.Services.Interfaces;
public interface ICommentService
{
    Task<CommentDto> AddAsync(int authorId, CommentCreateDto dto);
    Task<IEnumerable<CommentDto>> GetByTaskAsync(int taskId);
}
