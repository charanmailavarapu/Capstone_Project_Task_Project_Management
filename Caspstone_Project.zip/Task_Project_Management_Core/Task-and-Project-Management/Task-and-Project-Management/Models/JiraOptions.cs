namespace Task_Product_Management.Api.Models;
public class JiraOptions { public string? BaseUrl { get; set; } public string? Email { get; set; } public string? ApiToken { get; set; } }
