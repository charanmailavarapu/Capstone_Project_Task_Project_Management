namespace Task_Product_Management.Api.Models;
public enum UserRole { Viewer , TeamMember , ProjectManager , Admin  }
