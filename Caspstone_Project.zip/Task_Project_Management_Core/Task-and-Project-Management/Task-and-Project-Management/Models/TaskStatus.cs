namespace Task_Product_Management.Api.Models;
public enum TaskStatus { ToDo = 0, InProgress = 1, Done = 2 }
