namespace Task_Product_Management.Api.Models;
public class GoogleCalendarOptions { public string? ApiKey { get; set; } public string? CalendarId { get; set; } }
