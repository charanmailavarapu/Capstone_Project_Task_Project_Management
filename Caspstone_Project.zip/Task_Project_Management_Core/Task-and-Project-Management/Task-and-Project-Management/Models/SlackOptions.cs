namespace Task_Product_Management.Api.Models;
public class SlackOptions { public string? WebhookUrl { get; set; } }
