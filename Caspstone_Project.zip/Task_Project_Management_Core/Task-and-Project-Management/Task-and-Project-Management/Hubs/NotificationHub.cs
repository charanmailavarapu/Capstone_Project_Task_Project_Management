using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace TaskProjectManagement.Api.Hubs;

[Authorize]
public class NotificationHub : Hub { }
