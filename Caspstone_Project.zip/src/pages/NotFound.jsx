import React from 'react';
const NotFound = () => <div className="container"><h2>404</h2><p>Page not found.</p></div>;
export default NotFound;